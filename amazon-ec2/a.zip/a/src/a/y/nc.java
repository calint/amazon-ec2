package a.y;
import b.*;
//import static b.b.*;
public class nc extends a{
	static final long serialVersionUID=1;
	final public void to(final xwriter x)throws Throwable{
		x.pl(getClass().toString());
	}
}
