package a.y.j;
import b.*;
public class $ extends a{static final long serialVersionUID=1;public void to(final xwriter x)throws Throwable{
	x.ax(this).nl();
	x.style(s,"width:100%;height:200px;border:1px dotted green").inputTextArea(s);
	x.nl();
	x.pl("java source");
	x.style(o,"display:block;width:100%;height:200px;border:1px dotted green").output(o);
}
	synchronized public void x_(final xwriter x,final String q){
		final javawriter j=new javawriter();
		
		j.pckg("archive");
		j.uses("b","java.util");
		j.defpckcls();
			j.has("files","index");
			j.rend();
			j.rendend();
			j.xfunc("");
			j.xfuncend();
		j.clasend();
		x.xu(o,j.toString());
	}
	
	public a s;
	public a o;
}