package a.y.bureaucrat;
import b.a;
import b.xwriter;
public class bureau extends a{static final long serialVersionUID=1;public void to(final xwriter x)throws Throwable{x.pl(getClass().toString());}
	public crat c;
	public inbox i;
	public outbox o;
	public form f;
}