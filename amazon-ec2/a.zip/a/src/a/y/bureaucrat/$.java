package a.y.bureaucrat;
import b.a;
import b.xwriter;
public class $ extends a{static final long serialVersionUID=1;public void to(final xwriter x)throws Throwable{
	x.style();
	
	x.styleEnd();
	x.pl("bureaucrat");
	x.ul();
	x.ulEnd();
}
synchronized public void x_o(final xwriter x,final String s){
	x.xalert(s);
}

public bureaucracy b;
}
