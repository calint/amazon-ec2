package a.y.chs;
import b.a;
public abstract class piece extends a{
	static final long serialVersionUID=1;
	protected int color;
	public piece(int color){super();this.color=color;}
}
