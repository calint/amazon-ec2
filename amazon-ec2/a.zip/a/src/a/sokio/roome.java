package a.sokio;
import static b.b.*;
final class roome extends splace{static final long serialVersionUID=1;{
	summary="\n\n\n retro text game sokio\n\n u r in roome\n u c me\n exits: none\n todo: find an exit\n\nkeywords: look enter go back exit select take drop copy  say goto inventory\n";
	places_add(new file(path("a.budget")));
}}