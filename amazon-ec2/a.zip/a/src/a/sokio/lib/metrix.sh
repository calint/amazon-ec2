ls -lh ep2.soi
echo -n txt;cat ep2.soi|wc
echo -n zip;cat ep2.soi|gzip|wc
