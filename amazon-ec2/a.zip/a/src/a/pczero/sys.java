package a.pczero;
import b.a;
import b.xwriter;
public class sys extends a{
	static final long serialVersionUID=1;
	public void to(final xwriter x)throws Throwable{
		final vintage c=(vintage)pt();
		x.el(this).p(c.zntkns()).spc().p("[").p(vintage.fld("000",Integer.toHexString(c.pcr))).p("]:").p(vintage.fld("0000",Integer.toHexString(c.ir))).elend();
	}
}