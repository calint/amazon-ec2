package a.medusa.algebra;

public interface vector{}