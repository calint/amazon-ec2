package a.medusa.algebra;

import java.io.Serializable;

public class matrix implements Serializable{
	
	private static final long serialVersionUID=1;
}
