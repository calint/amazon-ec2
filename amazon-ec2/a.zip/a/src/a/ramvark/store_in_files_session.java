package a.ramvark;
public class store_in_files_session extends store_in_files{
//	protected path root(final Class<? extends itm>cls){return req.get().session().path(cls.getName());}
}
