package a.ramvark;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
public @Retention(RetentionPolicy.RUNTIME)@interface ls{
	Class<? extends itm>cls();
}
