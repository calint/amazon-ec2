package a.ramvark.ab;
import a.ramvark.ls;
import a.ramvark.lst;
public @ls(cls=content.class)class contents extends lst{static final long serialVersionUID=1;}
