package a.ramvark.ab;
import a.ramvark.ls;
import a.ramvark.lst;
public @ls(cls=item.class)class items extends lst{static final long serialVersionUID=1;}
