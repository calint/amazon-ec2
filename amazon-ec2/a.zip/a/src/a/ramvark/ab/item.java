package a.ramvark.ab;
import a.ramvark.an;
import a.ramvark.in;
import a.ramvark.itm;
public class item extends itm{static final long serialVersionUID=1;
//	@in(type=3)public items subitems;
//	@in(type=5)public a price;
	public @in an note;
}
