package a.ramvark;
public class store_cache_in_files extends store_cache{
}
