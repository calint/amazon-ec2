package a.ramvark;
public class store_cache_in_ram extends store_cache{
}
