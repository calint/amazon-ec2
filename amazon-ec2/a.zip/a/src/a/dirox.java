package a;
import b.*;
public class dirox extends diro{static final long serialVersionUID=1;{
	root(req.get().session().path());
	bits(BIT_ALL);
}}
