package a.linklocal;
import b.a;
import b.xwriter;
public class index extends a{
	static final long serialVersionUID=1;
	{System.out.println("hello firewall");}
	public void to(final xwriter x)throws Throwable{
		x.p(getClass().getName());
	}
}
