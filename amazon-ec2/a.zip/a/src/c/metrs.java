package c;
public final class metrs{
	public static long select;
	public static long ioevent;
	public static long iocon;
	public static long ioread;
	public static long iowrite;
	public static long input;
	public static long output;
}