package b;
public interface cacheable{
	String filetype();
	String contenttype();
	String lastmod();
	long lastmodupdms();
	boolean cacheforeachuser();
}