package d2;
final class eventcollision extends event{
	private object obj;
	public eventcollision(final object o){obj=o;}
	public object object(){return obj;}
}
