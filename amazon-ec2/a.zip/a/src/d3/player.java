package d3;
public interface player{
	double health();
	byte[]keys();
}