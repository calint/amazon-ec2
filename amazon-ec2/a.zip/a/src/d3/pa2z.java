package d3;
final class pa2z extends pa2{
	private static final long serialVersionUID=1L;
	int cf[];
	int clp_alland;
	int clp_allor;
	double z[];
	pa2z(int nbr){
		super(new int[nbr],new int[nbr],nbr);
		z=new double[nbr];
		cf=new int[nbr];
	}
}
