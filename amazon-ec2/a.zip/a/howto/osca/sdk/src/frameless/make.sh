gcc -o frameless frameless.c -lX11 -Wfatal-errors -Wall -Wextra&&
ls -l frameless
