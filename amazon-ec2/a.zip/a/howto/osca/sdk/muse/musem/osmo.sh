 ~/Downloads/nasm-2.11.02/nasm -o osmo.img osmo.s&&ls -la osmo.s osmo.img&&cat osmo.s|gzip|wc&&cat osmo.img|gzip|wc

