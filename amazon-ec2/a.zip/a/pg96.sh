#!/bin/sh
java -server -cp bin d3.net
