package a.mnp;
import b.a;
import b.xwriter;
public class $ extends a{static final long serialVersionUID=1;public void to(final xwriter x)throws Throwable{
	x.pl("mechnerd park");
}}