package a.ramvark.ab;
import a.ramvark.an;
import a.ramvark.in;
import a.ramvark.itm;
public class content extends itm{static final long serialVersionUID=1;
	@in(type=3)public contents subcontents;
	@in(type=4)public an body;
}
