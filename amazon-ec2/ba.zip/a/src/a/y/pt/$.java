package a.y.pt;
import b.a;
import b.xwriter;
public class $ extends a{static final long serialVersionUID=1;public void to(final xwriter x)throws Throwable{
	x.pl("public transport #1");
}
public static class road extends a{static final long serialVersionUID=1;public void to(final xwriter x)throws Throwable{x.pl(getClass().toString());}}
public static class rail extends a{static final long serialVersionUID=1;public void to(final xwriter x)throws Throwable{x.pl(getClass().toString());}}
public static class water extends a{static final long serialVersionUID=1;public void to(final xwriter x)throws Throwable{x.pl(getClass().toString());}}
public static class busstop extends a{static final long serialVersionUID=1;public void to(final xwriter x)throws Throwable{x.pl(getClass().toString());}}
public static class wifi extends a{static final long serialVersionUID=1;public void to(final xwriter x)throws Throwable{x.pl(getClass().toString());}}
public static class homepage extends a{static final long serialVersionUID=1;public void to(final xwriter x)throws Throwable{x.pl(getClass().toString());}}
public static class bus extends a{static final long serialVersionUID=1;public void to(final xwriter x)throws Throwable{x.pl(getClass().toString());}}
public static class maintenance extends a{static final long serialVersionUID=1;public void to(final xwriter x)throws Throwable{x.pl(getClass().toString());}}
public static class seat extends a{static final long serialVersionUID=1;public void to(final xwriter x)throws Throwable{x.pl(getClass().toString());}}
public static class engine extends a{static final long serialVersionUID=1;public void to(final xwriter x)throws Throwable{x.pl(getClass().toString());}}
public static class fuel extends a{static final long serialVersionUID=1;public void to(final xwriter x)throws Throwable{x.pl(getClass().toString());}}
public static class fuelstation extends a{static final long serialVersionUID=1;public void to(final xwriter x)throws Throwable{x.pl(getClass().toString());}}
public static class garage extends a{static final long serialVersionUID=1;public void to(final xwriter x)throws Throwable{x.pl(getClass().toString());}}
}