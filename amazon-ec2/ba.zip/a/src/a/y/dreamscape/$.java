package a.y.dreamscape;
import b.a;
import b.xwriter;
public class $ extends a{static final long serialVersionUID=1;public void to(final xwriter x)throws Throwable{
	if(pt()==null)x.style("html","margin:0 8em 0 8em;padding:0 3em 0 3em;box-shadow:0 0 .5em rgba(0,0,0,.5);border-radius:0em");
	x.nl();
	x.pl("dreamscape");
}
}