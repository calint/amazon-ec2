package a.pics;
public class upload extends a.upload{static final long serialVersionUID=1;
	protected String rootpath(){return"/pics";}
}