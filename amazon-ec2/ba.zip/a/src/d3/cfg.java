package d3;
public final class cfg{
	public static int cnt_bullet;
	public static int cnt_frag;
	public static int cnt_rpg;
	public static int fixed_dt_ms;
	public static boolean focus_target=true;
	public static boolean obj_rend_bsphere;
	public static boolean rend_gnd;
	public static boolean rend_hud=true;
	public static boolean rend_pgon_cull=true;
	//	public static boolean rend_sky;
	public static boolean rend_solid=true;
	public static boolean rend_wire=true;
	public static boolean rend_wire_pen=true;
	public static int rnd_seed=0;
	public static double scr_dist=768;
	public static boolean vhcl_trace=true;
	public static String net_server_port="8085";
	public static boolean gc_before_stats;
	public static String pkg="game";
	public static boolean in2screen3d=true;
	public static boolean rend_spc=true;
}
