#!/bin/sh
while true;do sh 0-do-tests.sh;done


