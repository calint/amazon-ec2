#ifndef CLONKY_CFG_H
#define CLONKY_CFG_H
#define wifigraphmax 128*1024
#define dyhr 3
#define ytop 0
#define width 150
#define align 0
#define default_graph_height 25
#endif
